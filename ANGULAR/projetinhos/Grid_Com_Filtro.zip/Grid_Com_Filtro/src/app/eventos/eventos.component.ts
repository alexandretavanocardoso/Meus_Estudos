import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-eventos',
  templateUrl: './eventos.component.html',
  styleUrls: ['./eventos.component.scss']
})

export class EventosComponent implements OnInit {

  _filtroLista: string = "";
  get filtroLista(): string{
    return this._filtroLista;
  } 
  set filtroLista(value: string){
    this._filtroLista = value;
    this.eventosFiltrados = this.filtroLista ? this.filtrarEventos(this.filtroLista) : this.eventos;
  }

  eventos: any = [
    {
      EventoId: 1,
      Tema: 'Angular',
      Local: 'Barra Bonita',
      Data: '2020/10/15',
      Lote:'1° Lote',
      QtdPessoas: 20,
      ImagemUrl: '../../img/img1.jpg'     
    },
    {
      EventoId: 2,
      Tema: '.NET',
      Local: 'Barra Bonita',
      Data: '2020/10/15',
      Lote:'2° Lote',
      QtdPessoas: 20,
      ImagemUrl: '../../img/img2.jpg'         
    },
    {
      EventoId: 3,
      Tema: '.NET Core',
      Local: 'Barra Bonita',
      Data: '2020/10/15',
      Lote:'3° Lote',
      QtdPessoas: 20,
      ImagemUrl: '../../img/img3.jpg'       
    },
    {
      EventoId: 4,
      Tema: '.NET e Angular',
      Local: 'Barra Bonita',
      Data: '2020/10/15',
      Lote: '4° Lote',
      QtdPessoas: 20,
      ImagemUrl: '../../img/img4.jpg'    
    },
    {
      EventoId: 5,
      Tema: 'Git',
      Local: 'Barra Bonita',
      Data: '2020/10/15',
      Lote:'Lote Unico',
      QtdPessoas: 20,
      ImagemUrl: '../img/img5.jpg'    
    },
    {
      EventoId: 6,
      Tema: 'GitHub',
      Local: 'Barra Bonita',
      Data: '2020/10/15',
      Lote:'Lote Unico',
      QtdPessoas: 20,
      ImagemUrl: '../img/img5.jpg'    
    },  
    {
      EventoId: 7,
      Tema: 'SQL Server',
      Local: 'Barra Bonita',
      Data: '2020/10/15',
      Lote:'Lote Unico',
      QtdPessoas: 20,
      ImagemUrl: '../img/img5.jpg'    
    },  
    {
      EventoId: 8,
      Tema: 'React',
      Local: 'Barra Bonita',
      Data: '2020/10/15',
      Lote:'Lote Unico',
      QtdPessoas: 20,
      ImagemUrl: '../img/img5.jpg'    
    },  
    {
      EventoId: 9,
      Tema: 'Vue js',
      Local: 'Barra Bonita',
      Data: '2020/10/15',
      Lote:'Lote Unico',
      QtdPessoas: 20,
      ImagemUrl: '../img/img5.jpg'    
    },  
    {
      EventoId: 10,
      Tema: 'Adobe XD',
      Local: 'Barra Bonita',
      Data: '2020/10/15',
      Lote:'Lote Unico',
      QtdPessoas: 20,
      ImagemUrl: '../img/img5.jpg'    
    }   
  ];

  eventosFiltrados: any = [];
  imagemLargura = 50;
  imagemMargin = 2;
  mostrarImagem = false;

  constructor() { }

  ngOnInit() {

  }

  filtrarEventos(filtrarPor: string): any{
    filtrarPor = filtrarPor.toLocaleLowerCase();
    return this.eventos.filter(
      (evento: { Tema: string; }) => evento.Tema.toLocaleLowerCase().indexOf(filtrarPor) !== -1
    );
  }

  alternarImage(){
    this.mostrarImagem = !this.mostrarImagem;
  }

}
