/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DateTimeFormatPipePipe } from './DateTimeFormatPipe.pipe';

describe('Pipe: DateTimeFormatPipee', () => {
  it('create an instance', () => {
    let pipe = new DateTimeFormatPipePipe();
    expect(pipe).toBeTruthy();
  });
});
