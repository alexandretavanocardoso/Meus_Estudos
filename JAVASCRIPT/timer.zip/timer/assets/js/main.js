// new Date(0);

let relogio = document.querySelector(".relogio");
let iniciar = document.querySelector(".iniciar");
let zerar = document.querySelector(".zerar");
let pausar = document.querySelector(".pausar");
let segundos = 0;
let timer;

function criarHoraPorSegundo(segundos){
    let data = new Date(segundos * 1000);
    return data.toLocaleTimeString("pt-br", {
        hour12: false,
        timeZone: "GMT"
    });
}

function zeraTimer(){
    clearInterval(timer);
    relogio.innerHTML = "00:00:00";
    segundos = 0;
}

function iniciarTimer(){
    relogio.classList.remove("pausado");
    clearInterval(timer);
    timer = setInterval(function() {
        segundos++;
        relogio.innerHTML = criarHoraPorSegundo(segundos);
    }, 800);
}

function pararTimer(){
    // Limpa o intervalo
    clearInterval(timer);
    relogio.classList.add("pausado");
}
