let paragrafo = document.querySelector(".paragrafo");
let ps = paragrafo.querySelectorAll("p");

// Pegando estilo computados do browser
let estilosBody = getComputedStyle(document.body);
let backgroundColor = estilosBody.backgroundColor

for(let p of ps){
    p.style.backgroundColor = backgroundColor;
    p.style.color = "white";
}